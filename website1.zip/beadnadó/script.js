//sticky navbar
	window.addEventListener('scroll',function(){
    var header = document.querySelector('header');
    header.classList.toggle('sticky',window.scrollY > 0 );
  });

//cards filter
const list = document.querySelectorAll(".list");
const card = document.querySelectorAll(".card");


for(let i = 0; i<list.length; i++){

  list[i].addEventListener('click',function(){

  for(let k = 0; k<list.length; k++){
  
  list[k].classList.remove('active');
  
  }
  
  this.classList.add('active');
         
  
  let dataFilter = this.getAttribute('data-filter');
  
  for( let p=0; p<card.length; p++)
  {
    card[p].classList.remove('active');
    card[p].classList.add('hide');

    
    if(card[p].getAttribute('data-item') == dataFilter || dataFilter == 'all'){
       card[p].classList.remove('hide');
       card[p].classList.add('active');
    }
  }
})
}